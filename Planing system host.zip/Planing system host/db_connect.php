<?php 

$conn= new mysqli('sql109.infinityfree.com','if0_37506496','7dXS4k7yjImEH','if0_37506496_planning_system')or die("Could not connect to mysql".mysqli_error($con));
