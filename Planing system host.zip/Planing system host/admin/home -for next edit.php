<?php 

require 'lang.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Languages</title>
</head>
<body>

	<style>

		body{
			font-family: tahoma;
		}
		header{
			display: flex;
			padding: 10px;
			justify-content: center;
			align-items: center;
		}

		header div{
			padding: 10px;
		}

		.dropdown{
			position: relative;
		}

		.dropdown-content{
			position: absolute;
			margin-top:10px;
			background-color: white;
			border: solid thin #aaa;
			padding: 10px;
		}

		.hide{
			display: none;
		}

		section{
			padding: 10px;
			max-width: 600px;
			margin:auto;
		}

	</style>
	<header>
		<div><a href="#"><?= __('Home')?></a></div>
		<div><a href="#"><?= __('About us')?></a></div>
		<div><a href="#"><?= __('Contact us')?></a></div>
		
		<div><a href="#"><?= __('Signup')?></a></div>
		<div><a href="#"><?= __('Logout')?></a></div>
		<div class="dropdown">
		
			<div class="dropdown-content hide">
				<div><a href="#"><?= __('Profile')?></a></div>
				<div><a href="#"><?= __('Settings')?></a></div>
				<div><a href="#"><?= __('Logout')?></a></div>
			</div>
		</div>
		<div class="dropdown">
			<a href="#"><?= __('Language')?></a>
			<div class="dropdown-content hide">
				<div><a href="home.php?lang=en">English</a></div>
				<div><a href="home.php?lang=or">Oromiffaa</a></div>
				<div><a href="home.php?lang=am">አማርኛ</a></div>
				<div><a href="home.php?lang=ha">ሀረሪ</a></div>
			</div>
		</div>
	</header>
	
	<?php
	function tableExists($table){
  global $db;
  $table_exit = $db->query('SHOW TABLES FROM '.DB_NAME.' LIKE "'.$db->escape($table).'"');
      if($table_exit) {
        if($db->num_rows($table_exit) > 0)
              return true;
         else
              return false;
      }
  }
  ?>
<?php

function count_by_id($table){
  global $db;
  if(tableExists($table))
  {
    $sql    = "SELECT COUNT(id) AS total FROM ".$db->escape($table);
    $result = $db->query($sql);
     return($db->fetch_assoc($result));
  }
}
?>
<?php
function count_id(){
  static $count = 1;
  return $count++;
}
?>
<?php
function remove_junk($str){
  $str = nl2br($str);
  $str = htmlspecialchars(strip_tags($str, ENT_QUOTES));
  return $str;
}
?>

	<section>
		
		<?php
 //$c_categorie     = count_by_id('categories');
 $planingD      = count_by_id('yearly_planD');
  $reportingD      = count_by_id('quarterone_achiv');
 //$c_sale          = count_by_id('sales');
 $Qtwo_reporting  = count_by_id('quartertwo_achiv');
 
?>

 
        </div>
		
          <h2 class="margin-top"> <?php  echo $planingD['total']; ?> </h2>
          <p class="text-muted">Plan of KPI</p>
        </div>
       </div>
    </div>
	</a>
    </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_sale['total']; ?></h2>
          <p class="text-muted">Reported KPI</p>
        </div>
       </div>
    
  
 a Latin professor at Hampden-Sydney College 
in Virginia, looked up one of the more obscure
	</section>
</body>

<script>
	
	var dropdowns = document.querySelectorAll(".dropdown");

	for (var i = 0; i < dropdowns.length; i++) {
		
		dropdowns[i].addEventListener('click',function(e){

			for (var x = 0; x < dropdowns.length; x++) {
				dropdowns[x].querySelector(".dropdown-content").classList.add("hide");
			}

			e.currentTarget.querySelector(".dropdown-content").classList.toggle("hide");
		});
	}

</script>
</html>