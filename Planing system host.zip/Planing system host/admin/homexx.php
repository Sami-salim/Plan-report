<?php 

//require 'lang.php';

?>
<html>
	<head>
		<meta charset="utf-8" />
	
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script	src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
	</head>
<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
	<title>Languages</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<style>

		body{
			font-family: tahoma;
		}
		header{
			display: flex;
			padding: 5px;
			justify-content: center;
			align-items: center;
			margin-top:5px;
		}

		header div{
			padding: 10px;
			
		}

		.dropdown{
			position: relative;
		}

		.dropdown-content{
			position: absolute;
			margin-top:10px;
			background-color: white;
			border: solid thin #aaa;
			padding: 10px;
		}

		.hide{
			display: none;
		}

		section{
			padding: 0px;
			max-width: 1000px;
			margin:auto;
		}

	</style>
	
	<div>
			
	<header>
	
	    <div class="dropdown">
		<div><h4><a href="#"><?= __('File')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		              <div class="dropdown-content hide">
				               <div><a href="adminhome.php"><?= __('Home')?></a></div>
				               <div><a href="#"><?= __('About us')?></a></div>
				               <div><a href="#"><?= __('Contact us')?></a></div>
				               <div><a href="#"><?= __('library')?></a></div>
		                </div>
		           </div>
		     <div class="dropdown">
		          <div><h4><a href="#"><?= __('Plan')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		                <div class="dropdown-content hide">
				               <div><a href="PlaningD.php"><?= __('plan D')?></a></div>
				               <div><a href="PlaningC.php"><?= __('plan C')?></a></div>
				               <div><a href="#"><?= __('plan A')?></a></div>
				               <div><a href="#"><?= __('plan S')?></a></div>
							   <div><a href="#"><?= __('approval')?></a></div>
		                </div>
		           </div>
		     <div class="dropdown">
		            <div><h4><a href="#"><?= __('Quarter One Report')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		                <div class="dropdown-content hide">
				                <div><a href="Qone_reportingd.php"><?= __('Qone Report D')?></a></div>
				                 <div><a href="Qone_reportingc.php"><?= __('Qone Report C')?></a></div>
				                 <div><a href="#"><?= __('Qone Report A')?></a></div>
				                 <div><a href="#"><?= __('Qone Report S')?></a></div>
		                </div>
		            </div>
			  <div class="dropdown">
		      <div><h4><a href="#"><?= __('Quarter Two Report')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			  <div class="dropdown-content hide">
				                <div><a href="Qtwo_reportingd.php"><?= __('Qtwo Report D')?></a></div>
				                 <div><a href="Qtwo_reportingc.php"><?= __('Qtwo Report C')?></a></div>
				                 <div><a href="#"><?= __('Qtwo Report A')?></a></div>
				                 <div><a href="#"><?= __('Qtwo Report S')?></a></div>
		                </div>
		            </div>
			  <div class="dropdown">
		      <div><h4><a href="#"><?= __('Quarter Three Report')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			  <div class="dropdown-content hide">
				                <div><a href="Qthree_reportingd.php"><?= __('Qthree Report D')?></a></div>
				                 <div><a href="Qthree_reportingc.php"><?= __('Qthree Report C')?></a></div>
				                 <div><a href="#"><?= __('Qthree Report A')?></a></div>
				                 <div><a href="#"><?= __('Qthree Report S')?></a></div>
		                </div>
		            </div>
		      <div class="dropdown">
		            <div><h4><a href="#"><?= __('Quarter Four Report')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			             <div class="dropdown-content hide">
				                  <div><a href="Qfour_reportingd.php"><?= __('Qfour Report D')?></a></div>
				                  <div><a href="Qfour_reportingc.php"><?= __('Qfour Report C')?></a></div>
				                  <div><a href="#"><?= __('Qfour Report A')?></a></div>
				                  <div><a href="#"><?= __('Qfour Report S')?></a></div>
			              </div>
		         </div>
		
		      <div class="dropdown">
			        <div><h4><a href="#"><?= __('Language')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			               <div class="dropdown-content hide">
				                   <div><a href="home.php?lang=en">English</a></div>
				                   <div><a href="home.php?lang=or">Oromiffaa</a></div>
				                   <div><a href="home.php?lang=am">አማርኛ</a></div>
				                   <div><a href="home.php?lang=ha">ሀረሪ</a></div>
			               </div>
		       </div>
			   <div class="dropdown">
		       <div><h4><a href="#"><?= __('User Management')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		             <div class="dropdown-content hide">
				                    <div><a href="#"><?= __('Profile')?></a></div>
				                  <div><a href="#"><?= __('Settings')?></a></div>
				                  <div><a href="#"><?= __('Logout')?></a></div>
				                  <div><a href="#"><?= __('Signup')?></a></div>
			               </div>
		           </div>
	</div>
		

	</header>
	<header class=header>
	<div>
	   <div>
	   
            
			<div>
			<h2><a href="#"><?= __('Admin Dashbord')?></a></h2>
			 </div>
			 <strong><?php echo date("F j, Y, g:i a");?></strong><div>
      </div>
       </div>
	



<div class="content">
	
</html>
  
	
	
	
	<?php
	function tableExists($table){
  global $db;
  $table_exit = $db->query('SHOW TABLES FROM '.DB_NAME.' LIKE "'.$db->escape($table).'"');
      if($table_exit) {
        if($db->num_rows($table_exit) > 0)
              return true;
         else
              return false;
      }
  }
  ?>
<?php

function count_by_id($table){
  global $db;
  if(tableExists($table))
  {
    $sql    = "SELECT COUNT(id) AS total FROM ".$db->escape($table);
    $result = $db->query($sql);
     return($db->fetch_assoc($result));
  }
}
?>
<?php
function count_id(){
  static $count = 1;
  return $count++;
}
?>
<?php
function remove_junk($str){
  $str = nl2br($str);
  $str = htmlspecialchars(strip_tags($str, ENT_QUOTES));
  return $str;
}
?>
</header>
<body>
	<section>
		
<div>
<h1><a href="#"></a></h1>
<p> </p> 

<!DOCTYPE HTML>

	<body>
		<div class="container">
			<h2 class="text-center mt-4 mb-3"><?= __('Planing Monitoring And Evaluasion System')?></a></h2>

			
		</div>
		<br><br><br><br>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<div class="card mt-4">
						<div class="card-header"><?= __('Pie Chart')?></div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="pie_chart"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card mt-4">
						<div class="card-header"><?= __('Doughnut Chart')?></div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="doughnut_chart"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card mt-4 mb-4">
						<div class="card-header"><?= __('Bar Chart')?></div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="bar_chart"></canvas>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card">
				<div class="card-header"><?= __('service delivery Survey')?> </div>
				<div class="card-body">
					<div class="form-group">
						<h3 class="mb-4"><?= __('The Over all regional service delivery status in 2024?')?></h3>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="programming_language" class="programming_language" id="programming_language_1" value="excellence" checked>
							<label class="form-check-label mb-2" for="programming_language_1"><?= __('excellence')?></label>
						</div>
						<div class="form-check">
							<input type="radio" name="programming_language" id="programming_language_2" class="form-check-input" value="Moderate">
							<label class="form-check-label mb-2" for="programming_language_2"><?= __('Moderate')?></label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="programming_language" class="programming_language" id="programming_language_3" value="low">
							<label class="form-check-label mb-3" for="programming_language_3"><?= __('low')?></label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="programming_language" class="programming_language" id="programming_language_4" value="very low">
							<label class="form-check-label mb-4" for="programming_language_4"><?= __('very low')?></label>
						</div>
					</div>
					<div class="form-group">
						<button type="button" name="submit_data" class="btn btn-primary" id="submit_data">Submit</button>
					</div>
				</div>
			</div>
	</body>
</html>

<script>
	
$(document).ready(function(){

	$('#submit_data').click(function(){

		var language = $('input[name=programming_language]:checked').val();

		$.ajax({
			url:"data.php",
			method:"POST",
			data:{action:'insert', language:language},
			beforeSend:function()
			{
				$('#submit_data').attr('disabled', 'disabled');
			},
			success:function(data)
			{
				$('#submit_data').attr('disabled', false);

				$('#programming_language_1').prop('checked', 'checked');

				$('#programming_language_2').prop('checked', false);

				$('#programming_language_3').prop('checked', false);

				alert("Your Feedback has been send...");

				makechart();
			}
		})

	});

	makechart();

	function makechart()
	{
		$.ajax({
			url:"data.php",
			method:"POST",
			data:{action:'fetch'},
			dataType:"JSON",
			success:function(data)
			{
				var language = [];
				var total = [];
				var color = [];

				for(var count = 0; count < data.length; count++)
				{
					language.push(data[count].language);
					total.push(data[count].total);
					color.push(data[count].color);
				}

				var chart_data = {
					labels:language,
					datasets:[
						{
							label:'Vote',
							backgroundColor:color,
							color:'#fff',
							data:total
						}
					]
				};

				var options = {
					responsive:true,
					scales:{
						yAxes:[{
							ticks:{
								min:0
							}
						}]
					}
				};

				var group_chart1 = $('#pie_chart');

				var graph1 = new Chart(group_chart1, {
					type:"pie",
					data:chart_data
				});

				var group_chart2 = $('#doughnut_chart');

				var graph2 = new Chart(group_chart2, {
					type:"doughnut",
					data:chart_data
				});

				var group_chart3 = $('#bar_chart');

				var graph3 = new Chart(group_chart3, {
					type:'bar',
					data:chart_data,
					options:options
				});
			}
		})
	}

});

</script>

  
</div>
	</section>
</body>

<script>
	
	var dropdowns = document.querySelectorAll(".dropdown");

	for (var i = 0; i < dropdowns.length; i++) {
		
		dropdowns[i].addEventListener('click',function(e){

			for (var x = 0; x < dropdowns.length; x++) {
				dropdowns[x].querySelector(".dropdown-content").classList.add("hide");
			}

			e.currentTarget.querySelector(".dropdown-content").classList.toggle("hide");
		});
	}
	

</script>
</html>