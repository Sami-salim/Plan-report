<?php

$sname= "sql109.infinityfree.com";
$unmae= "if0_37506496";
$password = "7dXS4k7yjImEH";

$db_name = "if0_37506496_planning_system";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
	echo "Connection failed!";
}