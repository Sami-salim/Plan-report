<?php 

require 'lang.php';

?>

<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
	<title>Languages</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<style>

		body{
			font-family: tahoma;
		}
		header{
			display: flex;
			padding: 15px;
			justify-content: center;
			align-items: center;
			margin-top:5px;
		}

		header div{
			padding: 10px;
			
		}

		.dropdown{
			position: relative;
		}

		.dropdown-content{
			position: absolute;
			margin-top:10px;
			background-color: white;
			border: solid thin #aaa;
			padding: 10px;
		}

		.hide{
			display: none;
		}

		section{
			padding: 0px;
			max-width: 600px;
			margin:auto;
		}

	</style>
	
	<div>
			
	<header>
		<div><h4><a href="adminhome.php"><?= __('Home')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<div><h4><a href="#"><?= __('About us')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<div><h4><a href="#"><?= __('Contact us')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		
		<div><h4><a href="#"><?= __('library')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<div><h4><a href="#"><?= __('approval')?></a></h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<div class="dropdown">
		<h4><a href="#"><?= __('User Management')?></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<div class="dropdown-content hide">
				<div><a href="#"><?= __('Profile')?></a></div>
				<div><a href="#"><?= __('Settings')?></a></div>
				<div><a href="#"><?= __('Logout')?></a></div>
				<div><a href="#"><?= __('Signup')?></a></div>
			</div>
		</div>
		<div class="dropdown">
			<h4><a href="#"><?= __('Language')?></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<div class="dropdown-content hide">
				<div><a href="home.php?lang=en">English</a></div>
				<div><a href="home.php?lang=or">Oromiffaa</a></div>
				<div><a href="home.php?lang=am">አማርኛ</a></div>
				<div><a href="home.php?lang=ha">ሀረሪ</a></div>
			</div>
		</div>
		<div><h4><a href="#"><?= __('Logout')?></a><h4></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		
	</div>
		

	</header>
	<header class=header>
	<div>
	   <div>
            <h2><br><br>
			&nbsp&nbsp&nbsp&nbsp<a href="#"><?= __('Admin Dashbord')?></a></h2><br><br><br><br><br><br>
       </div>
	

 <asside>

<ul>
   <li>
  
		<div>
		<li><a href="adminhome.php"><?= __('User Management')?></a></li>
		<li><a href="#"><?= __('sectoral category')?></a></li>
		<li><a href="planingD.php"><?= __('plan D')?></a></li>
		<li><a href="#"><?= __('Qone Report D')?></a></li>
		<li><a href="#"><?= __('Qtwo Report D')?></a></li>
		<li><a href="#"><?= __('Qthree Report D')?></a></li>
		<li><a href="#"><?= __('Qfour Report D')?></a></li>
		<li><a href="#"><?= __('plan C')?></a></li>
		<li><a href="#"><?= __('Qone Report C')?></a></li>
		<li><a href="#"><?= __('Qtwo Report C')?></a></li>
		<li><a href="#"><?= __('Qthree Report C')?></a></li>
		<li><a href="#"><?= __('Qfour Report C')?></a></li>
		<li><a href="#"><?= __('plan A')?></a></li>
		<li><a href="#"><?= __('Qone Report A')?></a></li>
		<li><a href="#"><?= __('Qtwo Report A')?></a></li>
		<li><a href="#"><?= __('Qthree Report A')?></a></li>
		<li><a href="#"><?= __('Qfour Report A')?></a></li>
		<li><a href="#"><?= __('plan S')?></a></li>
		<li><a href="#"><?= __('Qone Report S')?></a></li>
		<li><a href="#"><?= __('Qtwo Report S')?></a></li>
		<li><a href="#"><?= __('Qthree Report S')?></a></li>
		<li><a href="#"><?= __('Qfour Report S')?></a></li>
  <li>

</ul>
</asside>



<div class="content">
	
</html>
  
	
	
	
	<?php
	function tableExists($table){
  global $db;
  $table_exit = $db->query('SHOW TABLES FROM '.DB_NAME.' LIKE "'.$db->escape($table).'"');
      if($table_exit) {
        if($db->num_rows($table_exit) > 0)
              return true;
         else
              return false;
      }
  }
  ?>
<?php

function count_by_id($table){
  global $db;
  if(tableExists($table))
  {
    $sql    = "SELECT COUNT(id) AS total FROM ".$db->escape($table);
    $result = $db->query($sql);
     return($db->fetch_assoc($result));
  }
}
?>
<?php
function count_id(){
  static $count = 1;
  return $count++;
}
?>
<?php
function remove_junk($str){
  $str = nl2br($str);
  $str = htmlspecialchars(strip_tags($str, ENT_QUOTES));
  return $str;
}
?>
</header>
<body>
	<section>
		
<div>
<h1>Planing Monitoring And Evaluasion System</h1>
<p>  Ethiopian professor at Haramaya-univercity , looked up one of the more obscure futers of programing</p> 
</div>
	</section>
</body>

<script>
	
	var dropdowns = document.querySelectorAll(".dropdown");

	for (var i = 0; i < dropdowns.length; i++) {
		
		dropdowns[i].addEventListener('click',function(e){

			for (var x = 0; x < dropdowns.length; x++) {
				dropdowns[x].querySelector(".dropdown-content").classList.add("hide");
			}

			e.currentTarget.querySelector(".dropdown-content").classList.toggle("hide");
		});
	}

</script>
</html>