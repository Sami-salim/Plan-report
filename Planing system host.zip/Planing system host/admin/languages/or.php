<?php

$lang = [

"title" => 'siistamaa Qoppi karoraa tohhanna fii hordoffii',
	'Home'=>'Maanna',
	'About us'=>'wayaa kagnaa',
	'Contact us'=>'walqqunamttii kagna',
	
	'Signup'=>'gallmauu',
	'Logout'=>'baahhuu',
	
	'Language'=>'Affan',
	'Profile'=>'udayfano dunffa',
	'Settings'=>'jijirudaf',
	
	'User Management'=>'fayadamtota oganuu',
	'sectoral category'=>'Jarrmaayya secttrootaa',
	
	'Planing Monitoring And Evaluasion System'=>'siistamaa Qoppi karoraa tohhanna fii hordoffii',
	
	'plan D'=>'karoora Qoodama',
	'Qone Report D'=>'Gab Kur 1 ffaa Q',
	
	'Qtwo Report D'=>'Gab Kur 2 ffaa Q',
	'Qthree Report D'=>'Gab Kur 3 ffaa Q',
	'Qfour Report D'=>'Gab Kur 4 ffaa Q',
	
	'plan C'=>'karoora HIN Qoodama ',
	'Qone Report C'=>'Gab Kur 1 ffaa HNQ ',
	
	'Qtwo Report C'=>'Gab Kur 2 ffaa HNQ',
	'Qthree Report C'=>'Gab Kur 3 ffaa HNQ',
	'Qfour Report C'=>'Gab Kur 4 ffaa HNQ',
	
	'plan A'=>"karoora Dabalatuu",
	'Qone Report A'=>'Gab Kur 1 ffaa DBL',
	
	'Qtwo Report A'=>'Gab Kur 2 ffaa DBL',
	'Qthree Report A'=>'Gab Kur 3 ffaa DBL ',
	'Qfour Report A'=>'Gab Kur 4 ffaa DBL',
	
	'plan S'=>"karoora kan irrisu",
	'Qone Report S'=>'Gab Kur 1 ffaa IRSU ',
	
	'Qtwo Report S'=>'Gab Kur 2 ffaa IRSU',
	'Qthree Report S'=>'Gab Kur 3 ffaa IRSU ',
	'Qfour Report S'=>'Gab Kur 4 ffaa  IRSU',
	
	'Indicatore'=>'Agersiiftu hojjii',
	
	'library'=>'Mannaa Kittaabbaa',
	'approval'=>'Mirkkanayysuu',
	'Admin Dashbord'=>'Bakka ittinnmatanfatan',
	
	'File'=>'Failla',
	'Plan'=>'karoora',
	'Quarter One Report'=>'Gabbassa Kur 1 ffaa',
	'Quarter Two Report'=>'Gabbassa Kur 2 ffaa',
	'Quarter Three Report'=>'Gabbassa Kur 3 ffaa',
	'Quarter Four Report'=>'Gabbassa Kur 4 ffaa',
	
	 'Sl No'=>'l.k',
	'Indicatore'=>'Agersiiftu hojjii',
	'unit'=>'saafartuu',
	'baseline'=>'khaumsa',
	'yearly plan'=>'karrora jjiiaa',
	'Quarter one'=>'kan Kur 1 ffaa',
	'Quarter two'=>'kan Kur 2 ffaa',
	'Quarter three'=>'kan Kur 3 ffaa',
	'Quarter four'=>'kan Kur 4 ffaa',
	'rank'=>'ulffinaa',
	'code'=>'codii',
	'year'=>'jjiiaa',
	
	 'Edit'=>'haromsu',
	'Delete'=>'haquu',
	'Your Messages'=>'ergga',
	
	 'Add New'=>'haraya naqquu',
	'Data Export'=>'odayyfanoo gad bassu',
	'UPlode'=>'qichu',
	'Home'=>'Mannaa',
	
	'Quarterone_report'=>'Gabbassa Kur 1 ffaa',
	'Quartertwo_report'=>'Gabbassa Kur 2 ffaa',
	'Quarterthree_report'=>'Gabbassa Kur 3 ffaa',
	'Quarterfour_report'=>'Gabbassa Kur 4 ffaa',
	
	'Quarterone_achiv'=>'rawii Kur 1 ffaa',
	'Quartertwo_achiv'=>'rawii Kur 2 ffaa',
	'Quarterthree_achiv'=>'rawii Kur 3 ffaa',
	'Quarterfour_achiv'=>'rawii Kur 4 ffaa',
	
	'Quarterone_report'=>'የ1ኛ ሩብ አመት ሪፖርት',
	'Quartertwo_report'=>'የ2ኛ ሩብ አመት ሪፖርት',
	'Quarterthree_report'=>'የ3ኛ ሩብ አመት ሪፖርት',
	'Quarterfour_report'=>'የ4ኛ ሩብ አመት ሪፖርት',
	
	'Quarterone_achiv'=>'የ1ኛ ሩብ አመት ክንውን',
	'Quartertwo_achiv'=>'የ2ኛ ሩብ አመት ክንውን',
	'Quarterthree_achiv'=>'የ3ኛ ሩብ አመት ክንውን',
	'Quarterfour_achiv'=>'የ4ኛ ሩብ አመት ክንውን',
	
	'uptoq two_plan'=>'እስከ 2ኛ ሩብ አመት እቅድ',
	'uptoq two_report'=>'እስከ 2ኛ ሩብ አመት ሪፖርት',
	'uptoq two_achiv'=>'እስከ 2ኛ ሩብ አመት ክንውን',
	
	
	'uptoq three_plan'=>'እስከ 3ኛ ሩብ አመት እቅድ',
	'uptoq three_report'=>'እስከ 3ኛ ሩብ አመት ሪፖርት',
	'uptoq three_achiv'=>'እስከ 3ኛ ሩብ አመት ክንውን',
	
	
	'uptoq four_plan'=>'እስከ 4ኛ ሩብ አመት እቅድ',
	'uptoq four_report'=>'እስከ 4ኛ ሩብ አመት ሪፖርት',
	'uptoq four_achiv'=>'እስከ 4ኛ ሩብ አመት ክንውን',
	
	'rank_achiv'=>'የክብደት ክንውን',
	
	
	'Planing Monitoring And Evaluasion System'=>'systema Qooppii karoora hordoffii fii tohanaa',
	
	
	'service delivery Survey'=>'AAkkatta tajajila ittikanan qorachu',
	'The Over all regional service delivery status in 2024?'=>'Bara 2016 Waligala Nannoti tajajila kanamu sederka itijiru ? ',
	'excellence'=>'olana',
	'Moderate'=>'gidu jiraytu',
	'low'=>'gadaana',
	'very low'=>'baya gadaana ',
	
	'Pie Chart'=>'Pie Chart',
	'Doughnut Chart'=>'Doughnut Chart',
	'Bar Chart'=>'Bar Chart',
	
	'Report'=>'Gabbassa',
	'Dashbord'=>'Baka Itimattanffataan',
	'Experts'=>'Oggaysowaan',
	'Users'=>'Fayadamtotaa',
	'List'=>'Liisstii',
	
	
	'Office'=>'manna Hojjii',
	'Phone No'=>'Lakkoffsa Biillbilla',
	'First Name'=>'Maqqaa',
	'Last Name'=>'Maqqaa Akhakhoo',
	'Avatar'=>'Suurraa',
	
	'Choose file'=>'Faiilli Marati',
	'Email'=>'Email',
	'Password'=>'Quullffi',
	'Confirm Password'=>'Quullffi Mirkkanayysuu',
	'Save'=>'Khaaii',
	'Cancel'=>'Chuffii',
	
	
	'Add New Aproval'=>'Mirkkanayysaa Haraya Dabbali',
	'Add New User'=>'Fayadamtotaa Haraya Dabbali',
	'Add New Officer'=>'Oggaysowaan Haraya Dabbali',
	'Name'=>'Maqqaa',
	'Action'=>'Tarrkkannfii',
	'View'=>'Agarsisi',
	
	'Submit'=>'Naqii',
	'BACK'=>'iffboda dabbii',
	
	'TOTAL EDIT IDS'=>'IDS Walligala kan Jijjirama '
	
];