<!DOCTYPE html>
  <html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>Admin Dashbord</title>
  
  <link rel="stylesheet" type="text/css" href="admin.css">
   </head>
   <header>
   <body>
   <header class="header">
   
   
   </body>

<a href="">Admin Dashbord</a>
<div class="logout">
<a href="">Logout</a>
</div>
</header>
<asside>

<ul>
  <li>
     <a href="">User Management</a>
     
  </li>
  <li>
     <a href="">sectoral category</a>
     
  </li>
  <li>
     <a href="planingD.php">plan D</a><br>
	 <a href="Qone_reportingD.php">Qone Report D</a><br>
	 <a href="Qtwo_reportingD.php">Qtwo Report D</a><br>
	 <a href="Qthree_reportingD.php">Qthree Report D</a><br>
	 <a href="Qfour_reportingD.php">Qfour Report D</a><br>
     
  </li>
  <li>
     <a href="planingC.php">plan C</a><br>
     <a href="Qone_reportingC.php">Qone Report C</a><br>
	 <a href="Qtwo_reportingC.php">Qtwo Report C</a><br>
	 <a href="Qthree_reportingC.php">Qthree Report C</a><br>
	 <a href="Qfour_reportingC.php">Qfour Report C</a><br>
  </li>
  <li>
     <a href="planingA.php">plan A</a><br>
     <a href="Qone_reportingA.php">Qone Report A</a><br>
	 <a href="Qtwo_reportingA.php">Qtwo Report A</a><br>
	 <a href="Qthree_reportingA.php">Qthree Report A</a><br>
	 <a href="Qfour_reportingA.php">Qfour Report A</a><br>
  </li>
  <li>
     <a href="planingS.php">plan S</a><br>
     <a href="Qone_reportingS.php">Qone Report S</a><br>
	 <a href="Qtwo_reportingS.php">Qtwo Report S</a><br>
	 <a href="Qthree_reportingS.php">Qthree Report S</a><br>
	 <a href="Qfour_reportingS.php">Qfour Report S</a><br>
  </li>
  
</ul>
</asside>
<div class="content">

<div>
<h1>Planing Monitoring And Evaluasion System</h1>
<p>  Ethiopian professor at Haramaya-univercity , looked up one of the more obscure futers of programing</p> 
</div>
   

</html>