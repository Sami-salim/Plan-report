<?php 

require 'lang.php';

?>
<?php
  $page_title = 'Admin Home Page';
 // require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  // page_require_level(1);
?>
<?php
 //$c_categorie     = count_by_id('categories');
 //$planingD      = count_by_id('yearly_planD');
 //$c_sale          = count_by_id('yearly_planD');
 //$Qtwo_reporting  = count_by_id('quartertwo_achiv');
 //$c_user          = count_by_id('users');
 //$products_sold   = find_higest_saleing_product('10');
 //$recent_products = find_recent_product_added('5');
// $recent_yearly_pland=find_recent_achiv_added(5);
// $recent_sales    = find_recent_sale_added('5')
?>


  
<header class=header>
	<div>
	   <div>
	   
            
			<div>
			<h2><a href="#"><?= __('Admin Dashbord')?></a></h2>
			 </div>
			 <strong><?php echo date("F j, Y, g:i a");?></strong><div>
      </div>
       </div>
	
<head>
		<meta charset="utf-8" />
	
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script	src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
	</head>


</header>

<body>
	
	<section>
	<div>
		
<!DOCTYPE HTML>

	<body>
		<div class="container">
			<h2 class="text-center mt-4 mb-3"><?= __('Planing Monitoring And Evaluasion System')?></a></h2>

			<div class="card">
				<div class="card-header"><?= __('service delivery Survey')?> </div>
				<div class="card-body">
					<div class="form-group">
						<h3 class="mb-4"><?= __('The Over all regional service delivery status in 2024?')?></h3>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="programming_language" class="programming_language" id="programming_language_1" value="excellence" checked>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
							<label class="form-check-label mb-2" for="programming_language_1"><?= __('excellence')?></label>
						</div>
						<div class="form-check">
							<input type="radio" name="programming_language" id="programming_language_2" class="form-check-input" value="Moderate">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
							<label class="form-check-label mb-2" for="programming_language_2"><?= __('Moderate')?></label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="programming_language" class="programming_language" id="programming_language_3" value="low">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
							<label class="form-check-label mb-3" for="programming_language_3"><?= __('low')?></label>
						</div>
						<div class="form-check">
							<input class="form-check-input" type="radio" name="programming_language" class="programming_language" id="programming_language_4" value="very low">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
							<label class="form-check-label mb-4" for="programming_language_4"><?= __('very low')?></label>
						</div>
					</div>
					<div class="form-group">
						<button type="button" name="submit_data" class="btn btn-primary" id="submit_data">Submit</button>
					</div>
				</div>
			</div>
		</div>
		<br><br><br><br>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<div class="card mt-4">
						<div class="card-header"><?= __('Pie Chart')?></div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="pie_chart"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card mt-4">
						<div class="card-header"><?= __('Doughnut Chart')?></div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="doughnut_chart"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card mt-4 mb-4">
						<div class="card-header"><?= __('Bar Chart')?></div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="bar_chart"></canvas>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>

<script>
	
$(document).ready(function(){

	$('#submit_data').click(function(){

		var language = $('input[name=programming_language]:checked').val();

		$.ajax({
			url:"data.php",
			method:"POST",
			data:{action:'insert', language:language},
			beforeSend:function()
			{
				$('#submit_data').attr('disabled', 'disabled');
			},
			success:function(data)
			{
				$('#submit_data').attr('disabled', false);

				$('#programming_language_1').prop('checked', 'checked');

				$('#programming_language_2').prop('checked', false);

				$('#programming_language_3').prop('checked', false);

				alert("Your Feedback has been send...");

				makechart();
			}
		})

	});

	makechart();

	function makechart()
	{
		$.ajax({
			url:"data.php",
			method:"POST",
			data:{action:'fetch'},
			dataType:"JSON",
			success:function(data)
			{
				var language = [];
				var total = [];
				var color = [];

				for(var count = 0; count < data.length; count++)
				{
					language.push(data[count].language);
					total.push(data[count].total);
					color.push(data[count].color);
				}

				var chart_data = {
					labels:language,
					datasets:[
						{
							label:'Vote',
							backgroundColor:color,
							color:'#fff',
							data:total
						}
					]
				};

				var options = {
					responsive:true,
					scales:{
						yAxes:[{
							ticks:{
								min:0
							}
						}]
					}
				};

				var group_chart1 = $('#pie_chart');

				var graph1 = new Chart(group_chart1, {
					type:"pie",
					data:chart_data
				});

				var group_chart2 = $('#doughnut_chart');

				var graph2 = new Chart(group_chart2, {
					type:"doughnut",
					data:chart_data
				});

				var group_chart3 = $('#bar_chart');

				var graph3 = new Chart(group_chart3, {
					type:'bar',
					data:chart_data,
					options:options
				});
			}
		})
	}

});

</script>

</div>
	</section>

