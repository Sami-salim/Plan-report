<div class="container-fluid">
	<p>Evaluation is closed.</p>
</div>
<div class="modal-footer display p-0 m-0">
        <a href="./index.php" class="btn btn-primary bg-gradient-primary">Home</a>
</div>
<style>
	#uni_modal .modal-footer{
		display: none
	}
	#uni_modal .modal-footer.display{
		display: flex
	}
</style>